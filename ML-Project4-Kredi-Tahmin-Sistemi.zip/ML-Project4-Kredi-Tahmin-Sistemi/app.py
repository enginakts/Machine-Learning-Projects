from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
from joblib import load
import numpy as np

app = Flask(__name__)
CORS(app)

# Load the trained model
model = load('loan_prediction_model.joblib')

# Ana sayfa route'u ekleyin
@app.route('/')
def home():
    return render_template('predict.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = request.json
        
        # Create feature array from input data
        features = np.array([[
            float(data['gender']),
            float(data['married']),
            float(data['dependents']),
            float(data['education']),
            float(data['self_employed']),
            float(data['applicant_income']),
            float(data['coapplicant_income']),
            float(data['loan_amount']),
            float(data['loan_amount_term']),
            float(data['credit_history']),
            float(data['property_area'])
        ]])

        # Make prediction
        prediction = model.predict(features)
        
        return jsonify({
            'success': True,
            'prediction': int(prediction[0]),
            'message': 'Loan Approved' if prediction[0] == 1 else 'Loan Not Approved'
        })

    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        })

if __name__ == '__main__':
    app.run(debug=True)